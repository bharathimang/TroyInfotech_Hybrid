package pages;

public class LeavePage {

}
